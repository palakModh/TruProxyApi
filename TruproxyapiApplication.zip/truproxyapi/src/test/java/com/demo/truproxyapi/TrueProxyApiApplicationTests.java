package com.demo.truproxyapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;

@SpringBootTest
class TrueProxyApiApplicationTests {

	@Test
	void contextLoads() {
	}
}
